from django.contrib import admin
from .models import  About,Edu,Teaching,Experience,Todolist
admin.site.register(About)
admin.site.register(Edu)
admin.site.register(Teaching)
admin.site.register(Experience)
admin.site.register(Todolist)